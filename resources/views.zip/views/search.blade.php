<div class="widget responsive-layout none searchPageQSearchWrapper widget-none  widget-compact-all"
     id="cce16f2f-8af0-4b00-b166-20b5b842ca1f">
    <div class="wrapped ">
        <div class="widget-body body body-none  body-compact-all">
            <div class="container">
                <div class="row row-md gutterless ">
                    <div class="col-md-1-6 ">
                        <div class="contents" data-pb-dropzone="contents0">
                        </div>
                    </div>
                    <div class="col-md-3-4 ">
                        <div class="contents" data-pb-dropzone="contents1">
                            <div class="widget quickSearchWidget none  widget-none  widget-compact-all"
                                 id="0fd1abdb-192d-4369-9632-e6b32f1be5c9">
                                <div class="wrapped ">
                                    <div class="widget-body body body-none  body-compact-all">
                                        <div class="quickSearchFormContainer ">
                                            <form action="{{ route('article.search') }}"
                                                  name="quickSearch"
                                                  class="quickSearchForm "
                                                  title="Quick Search" role="search"
                                                  method="get"
                                                  aria-label="Quick Search"><span
                                                    class="simpleSearchBoxContainer">
<input name="term" class="searchText main-search-field autocomplete" value="" type="search"
       id="searchText-0fd1abdb-192d-4369-9632-e6b32f1be5c9" title="Type search term here" aria-label="Search"
       placeholder="Enter keywords, authors, subjects, titles, etc" autocomplete="off" data-history-items-conf="3"
       data-publication-titles-conf="3" data-publication-items-conf="3" data-topics-conf="3" data-contributors-conf="3"
       data-fuzzy-suggester="false" data-auto-complete-target="title-auto-complete"/>
</span>
                                                <span class="quick-search-btn">
<button class="mainSearchButton searchButtons pointer" title="Search" role="button" type="submit" value=""
        aria-label="Search"><i class="fas fa-search"></i></button>
</span></form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1-12 ">
                        <div class="contents" data-pb-dropzone="contents2">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
